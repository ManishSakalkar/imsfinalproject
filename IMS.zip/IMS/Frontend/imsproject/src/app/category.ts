export class Category {
    constructor(
    public id: number,
    public categoryname: string,
    public creationdate: string,
    
    ){}
}
