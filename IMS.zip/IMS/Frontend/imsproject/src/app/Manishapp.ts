export class Manishapp {
    constructor(
    public id: number,
    public policynamea: string,
    public creationa: string,
    public suma: string,
    public amounta: string,
    public interesta: string,
    
    ){}
}
