export class Problem {
    constructor(
    public id: number,
    public problemname: string,
    public message: string,
    public todayd: string,
    
    ){}
}
