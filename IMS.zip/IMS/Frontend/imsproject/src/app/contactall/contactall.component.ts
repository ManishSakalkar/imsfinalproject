import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactall',
  templateUrl: './contactall.component.html',
  styleUrls: ['./contactall.component.css']
})
export class ContactallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
