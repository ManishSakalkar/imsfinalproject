export class Manish {
    constructor(
    public id: number,
    public policyname: string,
    public creation: string,
    public sum: string,
    public amount: string,
    public interest: string,
    
    ){}
}
