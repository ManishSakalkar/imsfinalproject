import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policydashboard',
  templateUrl: './policydashboard.component.html',
  styleUrls: ['./policydashboard.component.css']
})
export class PolicydashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  images = ['../../assets/admin.png'];
}
