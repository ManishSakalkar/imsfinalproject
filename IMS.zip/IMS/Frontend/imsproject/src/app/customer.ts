export class Customer {
    constructor(
    public id: number,
    public mobilenumber: number,
    public name: string,
    public gender: string,
    public email: string,
    public addr: string,
    public usern: string,
    public password: string,
    
    ){}
}
