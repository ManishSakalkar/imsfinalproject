import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactedit',
  templateUrl: './contactedit.component.html',
  styleUrls: ['./contactedit.component.css']
})
export class ContacteditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
