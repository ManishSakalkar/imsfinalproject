package com.example.demo;

public @interface SpringBootTest {

}
