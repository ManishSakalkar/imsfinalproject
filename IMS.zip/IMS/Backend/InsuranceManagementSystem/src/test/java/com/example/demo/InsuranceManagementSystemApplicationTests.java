package com.example.demo;

import org.junit.Test;


@SpringBootTest
class InsuranceManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
