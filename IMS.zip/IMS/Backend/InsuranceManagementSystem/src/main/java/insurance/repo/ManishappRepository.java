package insurance.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import insurance.model.Manishapp;

public interface ManishappRepository extends JpaRepository<Manishapp, Integer>
{

}
