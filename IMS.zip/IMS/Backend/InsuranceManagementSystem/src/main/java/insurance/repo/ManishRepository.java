package insurance.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import insurance.model.Manish;

public interface ManishRepository extends JpaRepository<Manish, Integer>
{

}
